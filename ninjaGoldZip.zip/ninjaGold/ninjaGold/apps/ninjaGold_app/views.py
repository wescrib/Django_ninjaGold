#WILLIAM SCRIBNER

#CREATE WEBSITE WHERE WHEN THE USER PRESSES BUTTON THEY RECIEVE, OR POSSIBLY LOSE, RANDOM AMOUNTS OF NOTIONAL GOLD

#12 DEC 2017

from django.shortcuts import render,redirect
from random import *

# Create your views here.
def index(request):
    #SETTING GOLD TO 0 WHEN PAGE IS REFRESHED OR JUST OPENED
    if 'gold' not in request.session:
        request.session['gold'] = 0
    #CLEARING LIST OF MESSAGES THAT APPEARS AT THE BOTTOM OF A SCREEN WHEN THE USER CLICKS A BUTTON
    if 'activity' not in request.session:
        request.session['activity'] = []
    return render(request, "ninjaGold_app/index.html")

def process(request, location):
    print location

    #SETTINGS POSSIBLE VALUES THAT THE AMOUNT OF GOLD THE USER CAN RECIEVE WHEN A BUTTON IS PRESSED ON EACH LOCATION
    if location == "farm":
        gold=randrange(10,20)
        
    elif location == "house":
        gold=randrange(10,15)
    elif location == "cave":
        gold=randrange(10,100)

    #THIS IS FOR THE CASINO
    else:
        gold=randrange(-50,51)

    #SETTING UP A STRING VARIABLE FOR THE MESSAGE AT THE BOTTOM OF THE PAGE TO INGEST, DEPENDING ON IF GOLD WAS EARNED OR LOST
    if gold > 0:
        verb = "earned"
    else:
        verb = "lost"
    
    #SETTING UP MESSAGE TO BE INGESTED INTO AN ARRAY. 
    request.session['activity'].append("You {} {} golds from the {}".format(verb, abs(gold), location))
    request.session['gold'] += gold
    return redirect("/", gold=gold)